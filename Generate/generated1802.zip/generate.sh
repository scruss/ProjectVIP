python2 process.py
python2 binaryconv.py
cp *.h ../Miscellany/*.h ../CosmacVIP
